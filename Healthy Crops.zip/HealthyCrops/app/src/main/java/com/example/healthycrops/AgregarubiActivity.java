package com.example.healthycrops;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.healthycrops.Data.Repositorio;
import com.example.healthycrops.model.Sensor;
import com.example.healthycrops.model.Ubicacion;

import java.util.List;

public class AgregarubiActivity extends AppCompatActivity {

    private List<Ubicacion> ubicaciones;
    private EditText ubicacionEditText, descripcionEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregarubi);

        ubicaciones = Repositorio.getInstance().ubicaciones;
        Button ingresarUbicacionButton = findViewById(R.id.agregarUbicacionButton);
        ubicacionEditText = findViewById(R.id.nombreUbiEditText);
        descripcionEditText = findViewById(R.id.descripcionUbiEditText);

        ingresarUbicacionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregarUbicacionAlRepositorio();
            }
        });

    }
    private void agregarUbicacionAlRepositorio(){
        String nombre = ubicacionEditText.getText().toString().trim();
        String descripcion = descripcionEditText.getText().toString();

        if (nombre.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese el nombre", Toast.LENGTH_SHORT).show();
            return;
        }

        if (nombre.length() < 5 || nombre.length() > 15) {
            Toast.makeText(this, "El nombre debe tener entre 5 y 15 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!descripcion.isEmpty() && descripcion.length() > 30) {
            Toast.makeText(this, "La descripción debe tener un máximo de 30 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }
        if (descripcion.isEmpty()) {
            descripcion = "N/A";
        }

        Ubicacion nuevaUbicacion = new Ubicacion(nombre, descripcion);

        Repositorio.getInstance().agregarUbicacion(nuevaUbicacion);

        Toast.makeText(this, "Ubicación agergada: " + nuevaUbicacion.getNombre(), Toast.LENGTH_SHORT).show();

        finish();

    }
}